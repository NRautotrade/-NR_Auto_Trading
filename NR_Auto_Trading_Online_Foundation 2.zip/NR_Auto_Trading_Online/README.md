# NR Auto Trading — Online Multi-User Foundation

This is the web version of NR AUTO TRADING.

## What this version provides

- Online-style web dashboard structure
- NR account registration and login
- Separate users
- Demo / Real account mode in the dashboard
- Deriv OAuth 2.0 connection flow with PKCE
- Per-user Deriv account connection record
- Existing dashboard risk/protection settings:
  - Risk / Trade: $50
  - Reward / Risk: 2.0
  - Daily Target: $200
  - Maximum Daily Profit: $500
  - Maximum Daily Loss: $50
  - Protect at TP: 70%
  - Lock Profit: 1.0R
- M5 / strategy UI can be carried into the production frontend

## Important

This is the **online application foundation**, not a finished production trading service.

The old Windows bot uses MetaTrader 5. A shared online service cannot depend on your laptop's MT5 terminal for every user. The online trading worker must use Deriv's current API/WebSocket architecture and must map the ABC strategy, position rules, risk sizing, and protection logic to the Deriv contract types actually supported by the connected account.

Real-money trading is deliberately disabled by default with `ALLOW_REAL_TRADING=false`.

## Local run

1. Install Python 3.11+
2. Open a terminal in this folder
3. Run:

   py -m pip install -r requirements.txt

4. Copy `.env.example` to `.env` and set the secrets.
5. Run:

   py -m uvicorn app:app --reload

6. Open:

   http://127.0.0.1:8000

## Deriv setup

Create an OAuth 2.0 application in Deriv's developer dashboard and register the exact HTTPS callback:

`https://YOUR-DOMAIN.com/deriv/callback`

Use the generated client ID as `DERIV_CLIENT_ID`.

For a web product, OAuth 2.0 is preferred so users authorize NR Auto Trading through Deriv rather than giving NR Auto Trading their Deriv password.

## Deployment

Deploy this folder to an HTTPS-capable Python host. Set environment variables there rather than committing secrets to Git.

For a real public launch, also add:

- production database (PostgreSQL recommended)
- server-side secret management/KMS
- HTTPS-only cookies
- CSRF protection for all state-changing forms
- rate limiting
- email verification
- password reset
- audit logs
- background worker/queue
- per-user trading process isolation
- monitoring and alerts
- explicit real-trading confirmation and kill switch
- full Deriv API trading worker
